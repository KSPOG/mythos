MYTHOS SKYREACH V2 | Minecraft Java 1.21.1
Install the ZIP in the primary save's datapacks folder. Restart.
Use a separate Creative test world with open sky such as 0 160 0.
Run /execute positioned 0 160 0 run function mythos_skyreach_v2:build
The build writes blocks. Keep the area clear and use view distance 8 or more.
The arrival plaza is at 0 161 11 for this anchor.
Frame corner pairs for anchor 0 160 0:
 Cathedral       -3 163 -7     3 172 -7
 West            -52 160 15    -44 167 15
 East            43 160 15     51 167 15
 South           2 160 56      10 167 56
 Northwest       -42 160 -35   -34 167 -35
For each frame, use /mythosportal define <id> and right-click the two
corners. Then use the existing link and setarrival commands.
The generated gates and class stands are architectural build elements.
